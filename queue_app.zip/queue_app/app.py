"""
Smart Queue Management System
------------------------------
Run locally:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000  (customer view)
and   http://127.0.0.1:5000/admin (admin/counter view)
"""

import time
import sqlite3
from datetime import datetime, timedelta
from collections import defaultdict
from pathlib import Path

from flask import Flask, render_template, request, redirect, url_for, jsonify, flash, g

app = Flask(__name__)
app.config["SECRET_KEY"] = "college-project-secret-key"

DB_PATH = Path(__file__).parent / "queue.db"

MAX_RETRIES = 2
NOTIFY_WINDOW = 2
RATE_LIMIT_WINDOW = 60
RATE_LIMIT_MAX = 5


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS counter (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            active INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS ticket (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token_no INTEGER NOT NULL,
            name TEXT NOT NULL,
            contact TEXT,
            priority INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'waiting',
            counter_id INTEGER,
            retries INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL,
            called_at TEXT,
            completed_at TEXT,
            notified INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (counter_id) REFERENCES counter(id)
        );

        CREATE INDEX IF NOT EXISTS idx_ticket_status ON ticket(status);
        CREATE INDEX IF NOT EXISTS idx_ticket_priority_created
            ON ticket(priority, created_at);
        """
    )
    row = db.execute("SELECT COUNT(*) AS c FROM counter").fetchone()
    if row[0] == 0:
        db.execute("INSERT INTO counter (name, active) VALUES ('Counter 1', 1)")
        db.execute("INSERT INTO counter (name, active) VALUES ('Counter 2', 1)")
    db.commit()
    db.close()


def now_iso():
    return datetime.utcnow().isoformat(timespec="seconds")


def parse_dt(s):
    return datetime.fromisoformat(s) if s else None


_rate_log = defaultdict(list)


def is_rate_limited(ip):
    now = time.time()
    _rate_log[ip] = [t for t in _rate_log[ip] if now - t < RATE_LIMIT_WINDOW]
    if len(_rate_log[ip]) >= RATE_LIMIT_MAX:
        return True
    _rate_log[ip].append(now)
    return False


def avg_service_seconds(db):
    rows = db.execute(
        """SELECT called_at, completed_at FROM ticket
           WHERE status='done' AND called_at IS NOT NULL AND completed_at IS NOT NULL
           ORDER BY completed_at DESC LIMIT 20"""
    ).fetchall()
    if not rows:
        return 180
    durations = [
        (parse_dt(r["completed_at"]) - parse_dt(r["called_at"])).total_seconds()
        for r in rows
    ]
    return sum(durations) / len(durations) if durations else 180


def active_counter_count(db):
    row = db.execute("SELECT COUNT(*) AS c FROM counter WHERE active=1").fetchone()
    return max(row["c"], 1)


def count_ahead(db, priority, created_at):
    row = db.execute(
        """SELECT COUNT(*) AS c FROM ticket
           WHERE status='waiting' AND (
               priority > ? OR (priority = ? AND created_at < ?)
           )""",
        (priority, priority, created_at),
    ).fetchone()
    return row["c"]


def estimate_wait_minutes(db, priority, created_at):
    ahead = count_ahead(db, priority, created_at)
    counters = active_counter_count(db)
    seconds = (ahead / counters) * avg_service_seconds(db)
    return int(seconds // 60)


def next_token(db):
    row = db.execute("SELECT MAX(token_no) AS m FROM ticket").fetchone()
    return (row["m"] or 0) + 1


def pick_counter(db):
    counters = db.execute("SELECT * FROM counter WHERE active=1").fetchall()
    if not counters:
        return None
    best, best_count = None, None
    for c in counters:
        cnt = db.execute(
            "SELECT COUNT(*) AS c FROM ticket WHERE counter_id=? AND status='serving'",
            (c["id"],),
        ).fetchone()["c"]
        if best_count is None or cnt < best_count:
            best, best_count = c, cnt
    return best


def waiting_list(db):
    return db.execute(
        "SELECT * FROM ticket WHERE status='waiting' ORDER BY priority DESC, created_at ASC"
    ).fetchall()


@app.route("/")
def index():
    db = get_db()
    return render_template("index.html", waiting=waiting_list(db))


@app.route("/join", methods=["POST"])
def join():
    ip = request.remote_addr or "unknown"
    if is_rate_limited(ip):
        flash("Too many requests from your device. Please wait a minute and try again.", "error")
        return redirect(url_for("index"))

    name = request.form.get("name", "").strip()
    contact = request.form.get("contact", "").strip()
    priority = 1 if request.form.get("priority") == "on" else 0

    if not name:
        flash("Name is required.", "error")
        return redirect(url_for("index"))

    db = get_db()
    token_no = next_token(db)
    cur = db.execute(
        """INSERT INTO ticket (token_no, name, contact, priority, status, created_at)
           VALUES (?, ?, ?, ?, 'waiting', ?)""",
        (token_no, name, contact, priority, now_iso()),
    )
    db.commit()
    return redirect(url_for("ticket_status", ticket_id=cur.lastrowid))


@app.route("/ticket/<int:ticket_id>")
def ticket_status(ticket_id):
    db = get_db()
    ticket = db.execute("SELECT * FROM ticket WHERE id=?", (ticket_id,)).fetchone()
    if ticket is None:
        return "Ticket not found", 404

    position = None
    wait_minutes = None
    if ticket["status"] == "waiting":
        position = count_ahead(db, ticket["priority"], ticket["created_at"]) + 1
        wait_minutes = estimate_wait_minutes(db, ticket["priority"], ticket["created_at"])

        if position <= NOTIFY_WINDOW and not ticket["notified"]:
            db.execute("UPDATE ticket SET notified=1 WHERE id=?", (ticket_id,))
            db.commit()
            print(f"[NOTIFY] {ticket['name']} ({ticket['contact']}): "
                  f"You're #{position} in line, almost your turn!")

    return render_template(
        "ticket.html", ticket=ticket, position=position, wait_minutes=wait_minutes
    )


@app.route("/ticket/<int:ticket_id>/cancel", methods=["POST"])
def cancel_ticket(ticket_id):
    db = get_db()
    db.execute(
        "UPDATE ticket SET status='cancelled' WHERE id=? AND status='waiting'",
        (ticket_id,),
    )
    db.commit()
    return redirect(url_for("ticket_status", ticket_id=ticket_id))


@app.route("/ticket/<int:ticket_id>/status.json")
def ticket_status_json(ticket_id):
    db = get_db()
    ticket = db.execute("SELECT * FROM ticket WHERE id=?", (ticket_id,)).fetchone()
    if ticket is None:
        return jsonify(error="not found"), 404
    position = None
    if ticket["status"] == "waiting":
        position = count_ahead(db, ticket["priority"], ticket["created_at"]) + 1
    return jsonify(status=ticket["status"], position=position)


@app.route("/admin")
def admin():
    db = get_db()
    waiting = waiting_list(db)
    serving = db.execute("SELECT * FROM ticket WHERE status='serving'").fetchall()
    counters = db.execute("SELECT * FROM counter").fetchall()

    since = (datetime.utcnow() - timedelta(hours=24)).isoformat(timespec="seconds")
    completed_today = db.execute(
        "SELECT COUNT(*) AS c FROM ticket WHERE status='done' AND completed_at >= ?",
        (since,),
    ).fetchone()["c"]
    dead_letter = db.execute(
        "SELECT COUNT(*) AS c FROM ticket WHERE status='dead_letter'"
    ).fetchone()["c"]
    avg_wait = round(avg_service_seconds(db) / 60, 1)

    return render_template(
        "admin.html",
        waiting=waiting,
        serving=serving,
        counters=counters,
        completed_today=completed_today,
        dead_letter=dead_letter,
        avg_wait=avg_wait,
        queue_length=len(waiting),
    )


@app.route("/admin/call_next", methods=["POST"])
def call_next():
    db = get_db()
    counter = pick_counter(db)
    if not counter:
        flash("No active counters available.", "error")
        return redirect(url_for("admin"))

    next_ticket = db.execute(
        "SELECT * FROM ticket WHERE status='waiting' ORDER BY priority DESC, created_at ASC LIMIT 1"
    ).fetchone()
    if not next_ticket:
        flash("Queue is empty.", "info")
        return redirect(url_for("admin"))

    cur = db.execute(
        "UPDATE ticket SET status='serving', counter_id=?, called_at=? WHERE id=? AND status='waiting'",
        (counter["id"], now_iso(), next_ticket["id"]),
    )
    db.commit()
    if cur.rowcount == 0:
        flash("That ticket was already taken.", "error")
    return redirect(url_for("admin"))


@app.route("/admin/complete/<int:ticket_id>", methods=["POST"])
def complete_ticket(ticket_id):
    db = get_db()
    db.execute(
        "UPDATE ticket SET status='done', completed_at=? WHERE id=?",
        (now_iso(), ticket_id),
    )
    db.commit()
    return redirect(url_for("admin"))


@app.route("/admin/no_show/<int:ticket_id>", methods=["POST"])
def no_show(ticket_id):
    db = get_db()
    ticket = db.execute("SELECT * FROM ticket WHERE id=?", (ticket_id,)).fetchone()
    if ticket is None:
        return redirect(url_for("admin"))
    retries = ticket["retries"] + 1
    if retries > MAX_RETRIES:
        db.execute(
            "UPDATE ticket SET status='dead_letter', retries=? WHERE id=?",
            (retries, ticket_id),
        )
    else:
        db.execute(
            "UPDATE ticket SET status='waiting', counter_id=NULL, called_at=NULL, retries=? WHERE id=?",
            (retries, ticket_id),
        )
    db.commit()
    return redirect(url_for("admin"))


@app.route("/admin/counters/toggle/<int:counter_id>", methods=["POST"])
def toggle_counter(counter_id):
    db = get_db()
    db.execute("UPDATE counter SET active = 1 - active WHERE id=?", (counter_id,))
    db.commit()
    return redirect(url_for("admin"))


@app.route("/admin/counters/add", methods=["POST"])
def add_counter():
    db = get_db()
    count = db.execute("SELECT COUNT(*) AS c FROM counter").fetchone()["c"]
    name = request.form.get("counter_name", "").strip() or f"Counter {count + 1}"
    db.execute("INSERT INTO counter (name, active) VALUES (?, 1)", (name,))
    db.commit()
    return redirect(url_for("admin"))


# Initialize DB immediately on import so it works under gunicorn too
init_db()

if __name__ == "__main__":
    app.run(debug=True)
