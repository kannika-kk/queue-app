# Smart Queue Management System

## Run locally
```
pip install -r requirements.txt
python app.py
```
Then open http://127.0.0.1:5000

## Deploy on Render.com (free)
1. Upload this whole folder to a new GitHub repository.
2. On Render.com: New + > Web Service > select your repo.
3. Build Command: pip install -r requirements.txt
4. Start Command: gunicorn app:app
5. Choose the Free plan and click Create Web Service.
6. Wait for deployment, then copy the live URL Render gives you.

## Use in MIT App Inventor
1. Create a new project, add a WebViewer component.
2. Set the WebViewer's HomeUrl to your Render URL.
3. Build the app (.apk) and install it via the AI2 Companion QR code.
